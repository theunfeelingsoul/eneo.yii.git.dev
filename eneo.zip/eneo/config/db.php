<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yiieneo',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];

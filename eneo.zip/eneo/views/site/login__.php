<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form method="post" action="/web/site/login">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="text"  name="username" class="form-control" id="" placeholder="username">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="password"  class="form-control" id="" placeholder="Password">
  </div>
  
  <button type="submit" class="btn btn-default">Submit</button>
</form>

</body>
</html>
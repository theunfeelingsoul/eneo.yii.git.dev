<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Surveyques */


?>
<div class="surveyques-create">
	<div class="container">
		<div class="col-md-7 col-md-offset-3">
		 	<div id="thankyoutall">
				<h3><span class="glyphicon glyphicon-thumbs-up"> </span>  &nbsp;&nbsp;&nbsp;Thank you for your response</h3>
			</div>
		</div>
	</div>
</div>
